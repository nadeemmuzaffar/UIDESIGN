package easy.tuto.bottomnavigationfragmentdemo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Adapter.BestSellerAdapter;
import easy.tuto.bottomnavigationfragmentdemo.Adapter.InstaStoriesAdapter;
import easy.tuto.bottomnavigationfragmentdemo.model.BestSellerModel;
import easy.tuto.bottomnavigationfragmentdemo.model.InstaModel;

public class HomeFragment extends Fragment {
    private RecyclerView recyclerView,bestRecyc;
    private BestSellerAdapter bestSellerAdapter;
    private ImageView arrow_bck;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_home, container, false);
        arrow_bck=view.findViewById(R.id.arrow_bck);
        arrow_bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), ProductActivity.class);
                startActivity(i);
                ((Activity) getActivity()).overridePendingTransition(0, 0);
            }
        });


        recyclerView=view.findViewById(R.id.recylerInsta);
        bestRecyc=view.findViewById(R.id.best_sellerRecycler);
        List<InstaModel> list = new ArrayList<>();
        list.add(new InstaModel(R.drawable.image7));
        list.add(new InstaModel(R.drawable.image2));
        list.add(new InstaModel(R.drawable.image3));
        list.add(new InstaModel(R.drawable.image4));
        list.add(new InstaModel(R.drawable.image5));
        list.add(new InstaModel(R.drawable.image6));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerView.setLayoutManager(linearLayoutManager);
        InstaStoriesAdapter customAdapter = new InstaStoriesAdapter((Context) getContext(), (ArrayList<InstaModel>) list);
        recyclerView.setAdapter(customAdapter);

        List<BestSellerModel> bestSellerModels = new ArrayList<>();
        bestSellerModels.add(new BestSellerModel(R.drawable.image3,"HCP Designee","  Sugar Free Chocolate","$50"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image2,"HERSHEY'S","  Sugar Free Chocolate","$70"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image5,"LOVE CRUNCH","  Sugar Free Chocolate","$60"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image4,"FRUIT & CASHEW BUTTER","  Sugar Free Chocolate","$80"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image6,"VEGAN PROTEIN","  Sugar Free Chocolate","$40"));

        LinearLayoutManager bestManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        BestSellerAdapter bestSellerAdapter = new BestSellerAdapter((Context) getContext(), (ArrayList<BestSellerModel>) bestSellerModels);
        bestRecyc.setLayoutManager(bestManager);
        bestRecyc.setAdapter(bestSellerAdapter);

        return view;
    }
}