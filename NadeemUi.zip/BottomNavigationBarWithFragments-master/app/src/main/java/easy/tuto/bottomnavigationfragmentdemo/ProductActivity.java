package easy.tuto.bottomnavigationfragmentdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Adapter.ProductApdater;
import easy.tuto.bottomnavigationfragmentdemo.model.ProductModel;

public class ProductActivity extends AppCompatActivity {
    private RecyclerView productrecyclerView;
    private ProductApdater productApdater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        productrecyclerView=findViewById(R.id.productRecy);


        List<ProductModel> bestSellerModels = new ArrayList<>();
        bestSellerModels.add(new ProductModel(R.drawable.image3,"HCP Designee","  Sugar Free Chocolate","$50"));
        bestSellerModels.add(new ProductModel(R.drawable.image2,"HERSHEY'S","  Sugar Free Chocolate","$70"));
        bestSellerModels.add(new ProductModel(R.drawable.image5,"LOVE CRUNCH","  Sugar Free Chocolate","$60"));
        bestSellerModels.add(new ProductModel(R.drawable.image4,"FRUIT & CASHEW BUTTER","  Sugar Free Chocolate","$80"));
        bestSellerModels.add(new ProductModel(R.drawable.image6,"VEGAN PROTEIN","  Sugar Free Chocolate","$40"));
        bestSellerModels.add(new ProductModel(R.drawable.image3,"HCP Designee","  Sugar Free Chocolate","$50"));
        bestSellerModels.add(new ProductModel(R.drawable.image2,"HERSHEY'S","  Sugar Free Chocolate","$70"));
        bestSellerModels.add(new ProductModel(R.drawable.image5,"LOVE CRUNCH","  Sugar Free Chocolate","$60"));
        bestSellerModels.add(new ProductModel(R.drawable.image4,"FRUIT & CASHEW BUTTER","  Sugar Free Chocolate","$80"));
        bestSellerModels.add(new ProductModel(R.drawable.image6,"VEGAN PROTEIN","  Sugar Free Chocolate","$40"));

        LinearLayoutManager bestManager = new LinearLayoutManager(ProductActivity.this, LinearLayoutManager.VERTICAL, false);
        ProductApdater bestSellerAdapter = new ProductApdater((Context) ProductActivity.this, (ArrayList<ProductModel>) bestSellerModels);
        productrecyclerView.setLayoutManager(bestManager);
        productrecyclerView.setAdapter(bestSellerAdapter);

    }
}