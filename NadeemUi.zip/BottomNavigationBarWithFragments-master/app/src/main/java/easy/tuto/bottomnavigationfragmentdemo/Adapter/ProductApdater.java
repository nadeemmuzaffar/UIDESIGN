package easy.tuto.bottomnavigationfragmentdemo.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import easy.tuto.bottomnavigationfragmentdemo.R;
import easy.tuto.bottomnavigationfragmentdemo.model.ProductModel;

public class ProductApdater extends RecyclerView.Adapter<ProductApdater.MyviewHolder> {

    private Context mContext;
    private ArrayList<ProductModel> productModels;

    public ProductApdater(Context mContext, ArrayList<ProductModel> productModels) {
        this.mContext = mContext;
        this.productModels = productModels;
    }

    @NonNull
    @Override
    public ProductApdater.MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.single_product_row,parent,false);
        return new MyviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductApdater.MyviewHolder holder, int position) {
        holder.choco.setImageResource(productModels.get(position).getBestImg());
        holder.herys.setText(productModels.get(position).getName());
        holder.sugar.setText(productModels.get(position).getSugarFreename());
        holder.price_name.setText(productModels.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return productModels.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder {
        private ImageView choco;
        private TextView herys,sugar,price_name;
        public MyviewHolder(@NonNull View itemView) {
            super(itemView);

            choco=itemView.findViewById(R.id.im_choco);
            herys=itemView.findViewById(R.id.hershys);
            sugar=itemView.findViewById(R.id.sugar);
            price_name=itemView.findViewById(R.id.prices);
        }
    }
}
