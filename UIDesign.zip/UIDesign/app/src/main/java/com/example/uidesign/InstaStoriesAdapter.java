package com.example.uidesign;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uidesign.model.InstaModel;

import java.util.ArrayList;

public class InstaStoriesAdapter extends RecyclerView.Adapter<InstaStoriesAdapter.ViewHolder> {

    Context context;
    ArrayList<InstaModel> arrayList;

    public InstaStoriesAdapter(Context context, ArrayList<InstaModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public InstaStoriesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(context).inflate(R.layout.singleinsta_row,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InstaStoriesAdapter.ViewHolder holder, int position) {
        holder.stories.setImageResource(arrayList.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView stories;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            stories =itemView.findViewById(R.id.img_stories);


        }
    }
}
