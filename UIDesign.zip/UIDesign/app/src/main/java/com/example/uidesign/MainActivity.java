package com.example.uidesign;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Adapter;

import com.example.uidesign.model.BestSellerModel;
import com.example.uidesign.model.InstaModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView,bestRecyc;
    private BestSellerAdapter bestSellerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recylerInsta);
        bestRecyc=findViewById(R.id.best_sellerRecycler);
        List<InstaModel> list = new ArrayList<>();

        list.add(new InstaModel(R.drawable.image7));
        list.add(new InstaModel(R.drawable.image2));
        list.add(new InstaModel(R.drawable.image3));
        list.add(new InstaModel(R.drawable.image4));
        list.add(new InstaModel(R.drawable.image5));
        list.add(new InstaModel(R.drawable.image6));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerView.setLayoutManager(linearLayoutManager);
        InstaStoriesAdapter customAdapter = new InstaStoriesAdapter((Context) MainActivity.this, (ArrayList<InstaModel>) list);
        recyclerView.setAdapter(customAdapter);

        List<BestSellerModel> bestSellerModels = new ArrayList<>();
        bestSellerModels.add(new BestSellerModel(R.drawable.image3,"HCP Designee","  Sugar Free Chocolate","$50"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image2,"HERSHEY'S","  Sugar Free Chocolate","$70"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image5,"LOVE CRUNCH","  Sugar Free Chocolate","$60"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image4,"FRUIT & CASHEW BUTTER","  Sugar Free Chocolate","$80"));
        bestSellerModels.add(new BestSellerModel(R.drawable.image6,"VEGAN PROTEIN","  Sugar Free Chocolate","$40"));

        LinearLayoutManager bestManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        BestSellerAdapter bestSellerAdapter = new BestSellerAdapter((Context) MainActivity.this, (ArrayList<BestSellerModel>) bestSellerModels);
        bestRecyc.setLayoutManager(bestManager);
        bestRecyc.setAdapter(bestSellerAdapter);
    }
}