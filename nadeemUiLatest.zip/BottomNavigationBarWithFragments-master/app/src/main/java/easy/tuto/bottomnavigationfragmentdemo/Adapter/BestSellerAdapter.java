package easy.tuto.bottomnavigationfragmentdemo.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.R;
import easy.tuto.bottomnavigationfragmentdemo.model.BestSellerModel;

public class BestSellerAdapter extends RecyclerView.Adapter<BestSellerAdapter.MyViewHolder> {
    private Context mContext;
    private List<BestSellerModel> bestSellerModels;

    public BestSellerAdapter(Context mContext, List<BestSellerModel> bestSellerModels) {
        this.mContext = mContext;
        this.bestSellerModels = bestSellerModels;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view =LayoutInflater.from(mContext).inflate(R.layout.best_seller_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.choco.setImageResource(bestSellerModels.get(position).getBestImg());
        holder.herys.setText(bestSellerModels.get(position).getName());
        holder.sugar.setText(bestSellerModels.get(position).getSugarFreename());
        holder.price_name.setText(bestSellerModels.get(position).getPrice());

    }

    @Override
    public int getItemCount() {
      return bestSellerModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView choco;
        private TextView herys,sugar,price_name;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            choco=itemView.findViewById(R.id.im_choco);
            herys=itemView.findViewById(R.id.hershys);
            sugar=itemView.findViewById(R.id.sugar);
            price_name=itemView.findViewById(R.id.prices);
        }
    }
}
