package easy.tuto.bottomnavigationfragmentdemo.shop;

public class ModelShop {
    private String title;

    public ModelShop(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
