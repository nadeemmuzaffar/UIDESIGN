package easy.tuto.bottomnavigationfragmentdemo.shop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Adapter.BestSellerAdapter;
import easy.tuto.bottomnavigationfragmentdemo.R;
import easy.tuto.bottomnavigationfragmentdemo.model.BestSellerModel;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.shopHolder> {

    private Context shopContext;
     private List<ModelShop> modelShopList;

    public ShopAdapter(Context shopContext, List<ModelShop> modelShopList) {
        this.shopContext = shopContext;
        this.modelShopList = modelShopList;
    }

    @NonNull
    @Override
    public ShopAdapter.shopHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(shopContext).inflate(R.layout.horizon_title_single_row,parent,false);
        return new shopHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShopAdapter.shopHolder holder, int position) {
    holder.title_shop.setText(modelShopList.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return modelShopList.size();
    }

    public class shopHolder extends RecyclerView.ViewHolder {
        private TextView title_shop;
        public shopHolder(@NonNull View itemView) {
            super(itemView);
            title_shop=itemView.findViewById(R.id.tv_title);
        }
    }
}
