package easy.tuto.bottomnavigationfragmentdemo.model;

public class ProductModel {
    private int bestImg;
    private String name;
    private String sugarFreename;
    private String price;

    public ProductModel(int bestImg, String name, String sugarFreename, String price) {
        this.bestImg = bestImg;
        this.name = name;
        this.sugarFreename = sugarFreename;
        this.price = price;
    }

    public int getBestImg() {
        return bestImg;
    }

    public void setBestImg(int bestImg) {
        this.bestImg = bestImg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSugarFreename() {
        return sugarFreename;
    }

    public void setSugarFreename(String sugarFreename) {
        this.sugarFreename = sugarFreename;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
