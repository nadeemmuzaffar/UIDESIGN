package easy.tuto.bottomnavigationfragmentdemo.model;

public class InstaModel {
    private int image;

    public InstaModel(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
