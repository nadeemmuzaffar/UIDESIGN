package easy.tuto.bottomnavigationfragmentdemo;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Adapter.InstaStoriesAdapter;
import easy.tuto.bottomnavigationfragmentdemo.model.InstaModel;
import easy.tuto.bottomnavigationfragmentdemo.shop.ModelShop;
import easy.tuto.bottomnavigationfragmentdemo.shop.ShopAdapter;


public class NotificationFragment extends Fragment {
    private RecyclerView recyclerViewShop;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_notification, container, false);
        recyclerViewShop=view.findViewById(R.id.shopRecy);
        List<ModelShop> shops = new ArrayList<>();
        shops.add(new ModelShop("top"));
        shops.add(new ModelShop("shoes"));
        shops.add(new ModelShop("dress"));
        shops.add(new ModelShop("shorts"));
        shops.add(new ModelShop("top"));
        shops.add(new ModelShop("kurta"));
        shops.add(new ModelShop("T-Shirt"));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerViewShop.setLayoutManager(linearLayoutManager);
        ShopAdapter shopAdapter = new ShopAdapter((Context) getContext(), (ArrayList<ModelShop>) shops);
        recyclerViewShop.setAdapter(shopAdapter);
        return view;
    }
}